package animal;

public class Wolf extends Canine {

	@Override
	public void makeNoise() {
		// TODO Auto-generated method stub
		System.out.println("this is calm animal");

	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Veg olny");

	}

}
