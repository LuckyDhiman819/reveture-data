package animal;

public class Lion extends Feline {
	
	@Override
	public void makeNoise() {
		// TODO Auto-generated method stub
		System.out.println("This make Noise is roar");
		
	}
	
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Non-veg");
		
	}
	
}
