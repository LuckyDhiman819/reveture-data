package animal;

abstract public class Canine extends Animal {
	
	@Override
	public void roam() {
		
		System.out.println("This is Canine Function");
		
	}
	
}
