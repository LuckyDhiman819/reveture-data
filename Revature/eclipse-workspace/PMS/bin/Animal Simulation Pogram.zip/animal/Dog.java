package animal;

public class Dog extends Canine {

	@Override
	public void makeNoise() {
		// TODO Auto-generated method stub
		System.out.println("its noise is roar");

	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("non_veg and veg both");
	}

}
