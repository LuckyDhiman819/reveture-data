package animal;

public interface allMethod {
	
	String Picture = "";
	String foode = "";
	String hunger = "";
	String bounderies = "";
	String location = "";
}


//Animal Simulation Program