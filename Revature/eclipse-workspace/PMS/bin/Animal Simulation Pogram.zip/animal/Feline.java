package animal;

abstract class Feline extends Animal {
	
	@Override
	public void roam() {
		// TODO Auto-generated method stub
		System.out.println("caliing animal");
		
	}
}
