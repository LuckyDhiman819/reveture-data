package animal;

public class demo {
	public static void main(String[] args) {
		Hippo h = new Hippo();
		h.eat();
		h.makeNoise();
		
		Wolf w = new Wolf();
		w.eat();
		w.makeNoise();
		
		Tiger t = new Tiger();
		t.eat();
		t.makeNoise();
		
		Dog d = new Dog();
		d.eat();
		d.makeNoise();
		
		Lion l = new Lion();
		l.eat();
		l.makeNoise();
		
		Cat c = new Cat();
		c.eat();
		c.makeNoise();
//		
		
	}
}
