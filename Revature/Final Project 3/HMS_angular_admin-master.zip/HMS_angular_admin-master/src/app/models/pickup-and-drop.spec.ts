import { PickupAndDrop } from './pickup-and-drop';

describe('PickupAndDrop', () => {
  it('should create an instance', () => {
    expect(new PickupAndDrop()).toBeTruthy();
  });
});
