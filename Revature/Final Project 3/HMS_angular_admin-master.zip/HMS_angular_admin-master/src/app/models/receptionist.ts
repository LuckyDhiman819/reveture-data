export class Receptionist {
	receptionistId? : number;
	receptionistName? : String;
	receptionistPhoneNumber? : String;
	receptionistAge? : number;
	receptionistEmail? : String;
	receptionistPassword? : String;
	address? : String;
	experience? : String;
	salary? : number;
  json: any;
}
