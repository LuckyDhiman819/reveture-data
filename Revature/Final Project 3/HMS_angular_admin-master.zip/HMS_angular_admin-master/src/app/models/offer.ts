export class Offer {

	offerId?:number;
    roomType?:string;
    roomSize?:string;
    offerName?:string;
    offerFromDate?:any
	offerToDate?:any
    offerDetails?:string
	termsAndConditions?:string
    discountPercentage?:number

}
