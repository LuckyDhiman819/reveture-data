import { Offer } from './offer';

describe('Offer', () => {
  it('should create an instance', () => {
    expect(new Offer()).toBeTruthy();
  });
});
