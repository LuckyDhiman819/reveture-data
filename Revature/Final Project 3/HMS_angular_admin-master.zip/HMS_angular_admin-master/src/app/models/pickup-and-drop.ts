export class PickupAndDrop {
	pickupDropId?:number;
	location? : String;
	typeOfTransport? : String;
	time?: String;
	numberOfPassenger? : number;
}
