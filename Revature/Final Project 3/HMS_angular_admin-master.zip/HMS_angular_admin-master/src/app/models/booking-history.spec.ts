import { BookingHistory } from './booking-history';

describe('BookingHistory', () => {
  it('should create an instance', () => {
    expect(new BookingHistory()).toBeTruthy();
  });
});
