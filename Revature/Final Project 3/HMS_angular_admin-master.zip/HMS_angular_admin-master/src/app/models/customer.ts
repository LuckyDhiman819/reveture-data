export class Customer {
    customerName? : String;
    customerUserName? : String;
    password? : String;
    mobileNumber? : String;
    email? : String;
    gender? : String;
	age? : number;
    city? : String;
    state? : String;
    country? : String;
}
