export class ForgetPassword {

    customerUserName? : String;
	mobileNumber? : String; 
	password? : String;
}
