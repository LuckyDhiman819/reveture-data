export class Admin 
{
    adminId? : String;
	adminpassword? : String;
}
