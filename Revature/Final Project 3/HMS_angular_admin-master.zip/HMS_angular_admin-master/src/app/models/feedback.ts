export class Feedback {
    feedbackId?: number;
    username?: String;
    customerName?: String;
    phoneNumber?: number;
    rating?: number;
    suggestion?: String;

}
