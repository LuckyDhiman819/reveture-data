export class Bill {
    billNo:number;
    customerUserName:string;
    roomBill:number;
    discount:number;
    breakfastBill:number;
    drinksBill:number;
    foodBill:number;
    pickupAndDropBill:number;
    totalBill:number;
}
