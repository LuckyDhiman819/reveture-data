export class Wallet {
     customerUserName!:string;
	 walletAmount!:number;
}
