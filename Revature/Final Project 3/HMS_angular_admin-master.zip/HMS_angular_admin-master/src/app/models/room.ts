export class Room {

    roomId?:number;
	floorNumber?:number;
	roomSize?:string;
	roomType?:string;
	roomPrice?:number;
	roomView?:number;
	roomStatus?:boolean;
}
