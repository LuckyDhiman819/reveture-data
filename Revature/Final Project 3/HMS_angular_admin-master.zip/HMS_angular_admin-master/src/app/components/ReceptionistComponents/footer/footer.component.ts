import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-receptionist',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class ReceptionistFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
