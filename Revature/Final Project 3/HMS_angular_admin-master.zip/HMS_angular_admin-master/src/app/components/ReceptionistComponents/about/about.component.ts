import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-receptionist',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class ReceptionistAboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
