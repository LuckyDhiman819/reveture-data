import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-about',
  templateUrl: './customer-about.component.html',
  styleUrls: ['./customer-about.component.css']
})
export class CustomerAboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
