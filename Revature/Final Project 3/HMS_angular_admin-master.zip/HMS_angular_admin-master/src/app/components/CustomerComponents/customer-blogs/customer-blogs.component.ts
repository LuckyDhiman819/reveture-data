import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-blogs',
  templateUrl: './customer-blogs.component.html',
  styleUrls: ['./customer-blogs.component.css']
})
export class CustomerBlogsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
