

<?php


                echo $name;
                echo "</br>";
                echo $email;
                echo "</br>";
                echo $contact;          
                echo "</br>";
                echo $address;
                echo "</br>";
                echo $roomtype;
                echo "</br>";
                echo $checkin;
                echo "</br>";
                echo $checkout;
                echo "</br>";                
                echo $noofdays;
                echo "</br>";
                echo $payment;
                echo "</br>";
                echo $paymethod;
                echo "</br>";
                echo $customerid;
                echo "</br>";


?>

