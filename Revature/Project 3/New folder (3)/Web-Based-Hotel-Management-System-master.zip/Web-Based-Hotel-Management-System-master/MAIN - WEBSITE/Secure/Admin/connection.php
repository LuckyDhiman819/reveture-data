<?php 

$link=mysqli_connect("localhost","root","");
$db=mysqli_select_db($link,"hilton");


?>