import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resort-activities',
  templateUrl: './resort-activities.component.html',
  styleUrls: ['./resort-activities.component.css']
})
export class ResortActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
