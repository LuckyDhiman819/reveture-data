import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weddings',
  templateUrl: './weddings.component.html',
  styleUrls: ['./weddings.component.css']
})
export class WeddingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
