package com.exception;

public class InvalidAmountException extends RuntimeException {
	
	public InvalidAmountException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidAmountException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
