package com.exception;

public class InsufficientAmountException extends RuntimeException {

	public InsufficientAmountException() {
		// TODO Auto-generated constructor stub
	}
	public InsufficientAmountException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}
	
}
