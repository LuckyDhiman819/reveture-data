export class ForgetPassword {
    patientId:number;
    phoneNumber:string;
    password?: string;
    confirm_password?: string;
}
