import { ForgetPassword } from './admin-forget-password';

describe('ForgetPassword', () => {
  it('should create an instance', () => {
    expect(new ForgetPassword()).toBeTruthy();
  });
});
