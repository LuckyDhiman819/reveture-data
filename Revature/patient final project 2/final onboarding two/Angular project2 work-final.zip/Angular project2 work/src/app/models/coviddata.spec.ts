import { Coviddata } from './coviddata';

describe('Coviddata', () => {
  it('should create an instance', () => {
    expect(new Coviddata()).toBeTruthy();
  });
});
