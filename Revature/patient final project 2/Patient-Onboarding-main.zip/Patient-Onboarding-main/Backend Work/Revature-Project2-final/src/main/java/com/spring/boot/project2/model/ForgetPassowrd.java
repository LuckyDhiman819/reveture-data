package com.spring.boot.project2.model;

import lombok.Data;

@Data
public class ForgetPassowrd {
	
	private int id;
	private String phoneNumber;
	private String password;

}
