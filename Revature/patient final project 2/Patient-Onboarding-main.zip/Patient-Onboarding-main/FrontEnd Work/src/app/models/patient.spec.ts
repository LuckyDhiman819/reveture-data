import { Patient } from './patient';


describe('PatientLogin', () => {

  it('should create an instance', () => {
    expect(new Patient()).toBeTruthy();
  });
});
