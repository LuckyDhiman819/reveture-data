import { Admit } from './admit.model';

describe('Admit', () => {
  it('should create an instance', () => {
    expect(new Admit()).toBeTruthy();
  });
});
