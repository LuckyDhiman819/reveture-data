export class Admin {

    adminId:number;
    adminName?:String;
    password?:String;
    confirm_password?:String;
    email?:String;
    gender?:String;
    phoneNumber?:String;
    age?:Number;
    address?:String;
}
