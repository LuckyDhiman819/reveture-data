export class Doctors {

    doctorId?:number;
    doctorName? : string;
    department? : string;
    qualification? : string;
    expertise? : string;


}
