export class Bill {
    billNo? : number;
	patientId? : number;
	medicinePrice? : number;
	quantity? : number;
	surgeryCost? : number;
	appointmentCost? : number;
	doctorFees? : number;
	hospitalCharges? : number;
	otherCharges? : number;
	totalAmount? : number;
}
