export class ForgetPassword {
    adminId?:number;
    phoneNumber?:number;
    password?:String;
    confirm_password?:String;
}
