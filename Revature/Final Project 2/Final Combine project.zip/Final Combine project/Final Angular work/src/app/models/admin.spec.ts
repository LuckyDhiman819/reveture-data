import { Admin } from './admin';

<<<<<<< HEAD
describe('Admin', () => {
=======
describe('AdminLogin', () => {
>>>>>>> main
  it('should create an instance', () => {
    expect(new Admin()).toBeTruthy();
  });
});
