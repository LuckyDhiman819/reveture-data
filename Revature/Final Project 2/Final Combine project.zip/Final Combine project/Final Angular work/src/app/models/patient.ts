export class Patient {

    patientName?:String;
    patientId:number;
    password?:String;
    confirm_password?:String;
    email?:String;
    gender?:String;
    phoneNumber?:String;
    patientAge?:String;
    address?:String;
    idProof?:String;
    

}
