import { DisplayDirective } from './display.directive';

describe('DisplayDirective', () => {
  it('should create an instance', () => {
    const directive = new DisplayDirective();
    expect(directive).toBeTruthy();
  });
});
