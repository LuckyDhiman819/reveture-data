import { ForgetPassword } from './forget-password';

describe('forgetPassword', () => {
  it('should create an instance', () => {
    expect(new ForgetPassword()).toBeTruthy();
  });
});
