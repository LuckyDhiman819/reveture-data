package material;

public class CallingClass {
	public static void main(String[] args) {
		
	}

}
